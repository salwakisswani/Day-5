import UIKit

class AbilityDetails{
    
    
}
class Ability {
    let slot: UInt
    let isHidden: Bool
    let name: String
    let descriptionUrlString: String
    
    init? (with dictionary: [String:Any]) {
    guard let slot = dictionary["slot"] as? UInt,
    let isHidden = dictionary["is_hidden"] as? Bool,
    let ability = dictionary["ability"] as? [String: Any],
    let name = ability["name"] as? String,
    let descriptionUrlString = ability["url"] as? String
    else {return nil}
    self.slot = slot
    self.isHidden = isHidden
    self.name = name
    self.descriptionUrlString = descriptionUrlString
}
}
    
    class Pokemon {
    let species: String
    let indentifier: UInt
    let abilities: [Ability]
    let gameIndices: [Pokemon]
    
    init() {
        
        self.species = ""
        self.indentifier = 0
        self.abilities = []
        self.gameIndices = []
    }
    
    init?(with dictionary:[String:Any]){
      guard let speciesName = dictionary ["name"] as? String,
            let identifier = dictionary["id"] as? UInt,
            let gameIndices = dictionary["game_indices"] as? [[String: Any]],
            let abilities = dictionary["abilities"] as? [[String: Any]]
        else { return nil }
        self.species = speciesName
        self.indentifier = identifier
        self.abilities = abilities.compactMap({ Ability(with: $0) })
        self.gameIndices = gameIndices.compactMap({ Pokemon (with: $0) })
    }
    }

    if let url = Bundle.main.url(forResource: "PokemonExample", withExtension: "json"),
    let data = try? Data(contentsOf: url),
    let jsonObject = try? JSONSerialization.jsonObject(with: data, options:[]),
    let jsonDictionary = jsonObject as? [String: Any]  {
        let pokemon = Pokemon(with: jsonDictionary)
        print(pokemon!.gameIndices)
    
    
//   if jsonObject is [Any] {
    //print( "object is an aray")
//} else if jsonObject is [String: Any]
    //print("object us a dictionary")
   }
//} else {
  //  print("things aren't working anymore")


